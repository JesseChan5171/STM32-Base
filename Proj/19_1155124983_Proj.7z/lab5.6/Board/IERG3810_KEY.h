#ifndef __IERG3810_KEY_H
#define __IERG3810_KEY_H
#include "stm32f10x.h"

// put procedure header here

void IERG3810_KEY_Init();


#endif
