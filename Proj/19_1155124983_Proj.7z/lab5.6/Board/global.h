#ifndef __GLOBAL
#define __GLOBAL
#include "stm32f10x.h"

extern u8 task1HeartBeat;
extern u8 task2HeartBeat;
#endif
