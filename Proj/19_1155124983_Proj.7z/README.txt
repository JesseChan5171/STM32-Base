The Q&A part changed the game background color to blue, but it doesn't look good. So I changed it back to white.
The project refer to the lab5.6
The IERG3810_TFTLCD.c needed to include in the environment.