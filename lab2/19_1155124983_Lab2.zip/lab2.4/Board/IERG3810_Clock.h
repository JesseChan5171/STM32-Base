#include "stm32f10x.h"

void IERG3810_clock_tree_init(void);